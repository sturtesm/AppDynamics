var TransactionRules = require('../../lib/transactions/transaction-rules').TransactionRules
,   mocks = require('../lib/mocks');

describe('TransactionRules', function() {
    var agentMock, tr;

    beforeEach(function() {
        agentMock = new mocks.AgentMock();
        agentMock.configManager = new mocks.ConfigMock(agentMock);
        tr = new TransactionRules(agentMock);
    })

    function pushConfig(config) {
        agentMock.configManager.update(config);
    }

    describe('instances', function() {
        describe('constructor', function() {
            it('stores agent reference', function() {
                expect(tr.agent).toBe(agentMock);
            })
        })

        describe('#init()', function() {
            beforeEach(function() {
                tr.init();
            })

            it('initializes custom rules', function() {
                expect(tr.customMatches).toBeDefined();
                expect(Array.isArray(tr.customMatches)).toBe(true);
                expect(tr.customMatches.length).toBe(0);
            })
            it('initializes exclude rules', function() {
                expect(tr.customExcludes).toBeDefined();
                expect(Array.isArray(tr.customExcludes)).toBe(true);
                expect(tr.customExcludes.length).toBe(0);
            })
        })

        describe('on config update', function() {
            beforeEach(function() {
                tr.init();
            })

            describe('loads custom rules correctly', function() {
                it('when not configured', function() {
                    pushConfig({}); // trigger configUpdated
                    expect(tr.customMatches.length).toBe(0);
                })
                it('when empty', function() {
                    pushConfig({ 'txConfig.nodejsWeb.customDefinitions': [] });
                    expect(tr.customMatches.length).toBe(0);
                })
                it('in priority order', function() {
                    pushConfig({ 
                        'txConfig.nodejsWeb.customDefinitions': 
                        [ { id: 1, btName: 'test1', priority: 1, condition: {} }
                        , { id: 2, btName: 'test2', priority: 2, condition: {} }
                        , { id: 3, btName: 'test3', priority: 3, condition: {} }
                        ]
                    })
                    expect(tr.customMatches.length).toBe(3);
                    expect(tr.customMatches[0].btName).toBe('test1');
                    expect(tr.customMatches[1].btName).toBe('test2');
                    expect(tr.customMatches[2].btName).toBe('test3');
                })
                it('with header names mapped to lower case', function() {
                    pushConfig({
                        'txConfig.nodejsWeb.customDefinitions': 
                        [ { id: 1, btName: 'test-header', priority: 1, condition: { http: { 
                            headers: [{ type: 0, key: { type: 'EQUALS', matchStrings: ['Host'] }}] 
                        }}}]
                    })
                    expect(tr.customMatches[0].btName).toBe('test-header');
                    expect(tr.customMatches[0].condition.http.headers[0].key.matchStrings[0]).toBe('host');
                })
            })

            describe('loads custom excludes correctly', function() {
                it('when not configured', function() {
                    pushConfig({}); // trigger configUpdated
                    expect(tr.customExcludes.length).toBe(0);
                })
                it('when empty', function() {
                    pushConfig({ 'txConfig.nodejsWeb.discoveryConfig.excludes': [] });
                    expect(tr.customExcludes.length).toBe(0);
                })
                it('with header names mapped to lower case', function() {
                    pushConfig({
                        'txConfig.nodejsWeb.discoveryConfig.excludes': 
                        [{ headers: [{ type: 0, key: { type: 'EQUALS', matchStrings: ['Host'] }}] }]
                    })
                    expect(tr.customExcludes[0].headers[0].key.matchStrings[0]).toBe('host');
                })
            })
        })

        describe('after init', function() {
            beforeEach(function() {
                tr.init();
            })

            describe('#match()', function() {
                it('short circuits whem match is found', function() {
                    var count, tx = {}, props = {};

                    tr.customMatches = [
                        { btName: 'bt1', condition: { http: { properties: props } } },
                        { btName: 'bt2', condition: { http: { properties: props } } },
                        { btName: 'bt3', condition: { http: { properties: props } } }
                    ];

                    count = tr.customMatches.length;
                    spyOn(TransactionRules, 'matchesRule').andCallFake(function() {
                        return --count == 1;
                    });

                    tr.match(null, tx);

                    expect(TransactionRules.matchesRule).toHaveBeenCalled();
                    expect(TransactionRules.matchesRule.calls.length).toBe(2);
                    expect(tx.customNaming).toBe(props);
                })
            })

            describe('#exclude()', function() {
                it('returns false on empty ruleset', function() {
                    expect(tr.customExcludes.length).toBe(0);
                    expect(tr.exclude()).toBe(false);
                })
                it('returns false when no rules exclude', function() {
                    tr.customExcludes = [
                        { btName: 'bt1', condition: {} },
                        { btName: 'bt2', condition: {} },
                        { btName: 'bt3', condition: {} }
                    ];

                    spyOn(TransactionRules, 'matchesRule').andReturn(false);

                    expect(tr.exclude()).toBe(false);
                    expect(TransactionRules.matchesRule).toHaveBeenCalled();
                    expect(TransactionRules.matchesRule.calls.length).toBe(3);
                })
                it('short circuits whem exclude is found', function() {
                    var count;

                    tr.customExcludes = [
                        { btName: 'bt1', condition: {} },
                        { btName: 'bt2', condition: {} },
                        { btName: 'bt3', condition: {} }
                    ];

                    count = tr.customExcludes.length;
                    spyOn(TransactionRules, 'matchesRule').andCallFake(function() {
                        return --count == 1;
                    });

                    expect(tr.exclude()).toBe(true);
                    expect(TransactionRules.matchesRule).toHaveBeenCalled();
                    expect(TransactionRules.matchesRule.calls.length).toBe(2);
                })
            })
        })

        describe('matchesRule()', function() {
            function mockRequest(props) {
                var req = { 
                    method: 'GET',
                    url: '/',
                    headers: {},
                    connection: {
                        localPort: 80
                    }
                };

                if (props) {
                    for (var prop in props) {
                        req[prop] = props[prop];
                    }
                }

                return req;
            }

            function match(req, rule) {
                return TransactionRules.matchesRule(
                    mockRequest(req),
                    rule);
            }

            describe('matches on', function() {
                it('HTTP method', function() {
                    var rule = { method: 'GET' };
                    expect(match({ method: 'GET' }, rule)).toBe(true);
                    expect(match({ method: 'POST' }, rule)).toBe(false);
                })

                it('URI', function() {
                    expect(match({ url: '/foo' }, { uri: { type: 'EQUALS', matchStrings: ['/foo'] }})).toBe(true);
                    expect(match({ url: '/foo' }, { uri: { type: 'EQUALS', matchStrings: ['/bar'] }})).toBe(false);
                })

                describe('Port', function() {
                    it('from Host header', function() {
                        expect(match(
                            { headers: { host: 'example.com:8080' }}, 
                            { port: { type: 'EQUALS', matchStrings: ['8080'] }}
                        )).toBe(true);
                    })
                    it('from socket connection', function() {
                        expect(match(
                            {},
                            { port: { type: 'EQUALS', matchStrings: ['80'] }}
                        )).toBe(true);
                    })
                })
                
                it('Host', function() {
                    expect(match(
                        { headers: { host: 'example.com:8080' }}, 
                        { host: { type: 'EQUALS', matchStrings: ['example.com'] }}
                    )).toBe(true);
                })

                describe('params', function() {
                    var req = { url: '/some/path?p1=0&p2=foo&p3=bar' };

                    it('existing', function() {
                        expect(match(req, { params: [
                            { type: 'CHECK_FOR_EXISTENCE'
                            , key:  { type: 'EQUALS', matchStrings: [ 'p1' ], isNot: false }
                            }
                        ]})).toBe(true)
                    })
                    it('matching value', function() {
                        expect(match(req, { params: [
                            { type:  'COMPARE_VALUE' 
                            , key:   { type: 'EQUALS', matchStrings: [ 'p2' ], isNot: false }
                            , value: { type: 'EQUALS', matchStrings: [ 'foo' ], isNot: false } 
                            }
                        ]})).toBe(true)
                    })
                    it('and fails without match', function() {
                        expect(match(req, { params: [
                            { type: 'CHECK_FOR_EXISTENCE'
                            , key:  { type: 'EQUALS', matchStrings: [ 'pX' ], isNot: false }
                            }
                        ]})).toBe(false)
                    })
                })

                describe('cookies', function() {
                    var req = mockRequest({ cookies: { c1: 0, c2: 'foo' }});

                    it('existing', function() {
                        expect(match(req, { cookies: [
                            { type: 'CHECK_FOR_EXISTENCE'
                            , key:  { type: 'EQUALS', matchStrings: ['c1'] }
                            }
                        ]})).toBe(true);
                    })
                    it('matching value', function() {
                        expect(match(req, { cookies: [
                            { type:  'COMPARE_VALUE'
                            , key:   { type: 'EQUALS', matchStrings: ['c2'] }
                            , value: { type: 'EQUALS', matchStrings: ['foo'] }
                            }
                        ]})).toBe(true);
                    })
                    it('and fails without match', function() {
                        expect(match(req, { cookies: [
                            { type: 'CHECK_FOR_EXISTENCE'
                            , key:  { type: 'EQUALS', matchStrings: [ 'cX' ], isNot: false }
                            }
                        ]})).toBe(false)
                    })
                })

                describe('request headers', function() {
                    var req = mockRequest({ headers: { h1: 0, h2: 'foo' }});

                    it('existing', function() {
                        expect(match(req, { headers: [
                            { type:  'CHECK_FOR_EXISTENCE'
                            , key:   { type: 'EQUALS', matchStrings: ['h1'] }
                            }
                        ]})).toBe(true);
                    })
                    it('matching value', function() {
                        expect(match(req, { headers: [
                            { type:  'COMPARE_VALUE'
                            , key:   { type: 'EQUALS', matchStrings: ['h2'] }
                            , value: { type: 'EQUALS', matchStrings: ['foo'] }
                            }
                        ]})).toBe(true);
                    })
                    it('and fails without match', function() {
                        expect(match(req, { headers: [
                            { type: 'CHECK_FOR_EXISTENCE'
                            , key:  { type: 'EQUALS', matchStrings: [ 'hX' ], isNot: false }
                            }
                        ]})).toBe(false)
                    })
                })
            })
        })
    })
})
