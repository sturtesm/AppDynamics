var TransactionRules = require('../../lib/transactions/transaction-rules').TransactionRules
,   Matcher = TransactionRules.Matcher
,   MC = Matcher.MatchCondition
,   MR = Matcher.MatchResult;

describe('TransactionRules.StringMatch', function() {
    describe('matchString()', function() {
        function matchString(type, matchStrings, input) {
            return Matcher.matchString({ type: type, matchStrings: matchStrings }, input);
        }

        describe('without match strings', function() {
            describe('returns INVALID_CONDITION', function() {
                it('on EQUALS',        function() { expect(matchString(MC.EQUALS,        undefined)).toBe(MR.INVALID_CONDITION) })
                it('on STARTS_WITH',   function() { expect(matchString(MC.STARTS_WITH,   undefined)).toBe(MR.INVALID_CONDITION) })
                it('on ENDS_WITH',     function() { expect(matchString(MC.ENDS_WITH,     undefined)).toBe(MR.INVALID_CONDITION) })
                it('on CONTAINS',      function() { expect(matchString(MC.CONTAINS,      undefined)).toBe(MR.INVALID_CONDITION) })
                it('on MATCHES_REGEX', function() { expect(matchString(MC.MATCHES_REGEX, undefined)).toBe(MR.INVALID_CONDITION) })
            })
            describe('returns EMPTY_CONDITION', function() {
                it('on IS_IN_LIST',    function() { expect(matchString(MC.IS_IN_LIST,    undefined)).toBe(MR.EMPTY_CONDITION) })
                it('on IS_NOT_EMPTY)', function() { expect(matchString(MC.IS_NOT_EMPTY,  undefined)).toBe(MR.EMPTY_CONDITION) })
            })
        })

        describe('with multiple match strings', function() {
            describe('always returns UNMATCHED', function() {
                it('on EQUALS',        function() { expect(matchString(MC.EQUALS, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
                it('on STARTS_WITH',   function() { expect(matchString(MC.STARTS_WITH, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
                it('on ENDS_WITH',     function() { expect(matchString(MC.ENDS_WITH, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
                it('on CONTAINS',      function() { expect(matchString(MC.CONTAINS, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
                it('on MATCHES_REGEX', function() { expect(matchString(MC.MATCHES_REGEX, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
                it('on IS_NOT_EMPTY',  function() { expect(matchString(MC.IS_NOT_EMPTY, ['a','b','c'], '...')).toBe(MR.UNMATCHED) })
            })
        })

        describe('for match condition', function() {
            describe('EQUALS', function() {
                it('matches empty string', function() {
                    expect(matchString(MC.EQUALS, [''], '')).toBe(MR.MATCHED)
                    expect(matchString(MC.EQUALS, [''], 'foo')).toBe(MR.UNMATCHED)
                })
                it('matches non-empty string', function() {
                    expect(matchString(MC.EQUALS, ['foo'], '')).toBe(MR.UNMATCHED)
                    expect(matchString(MC.EQUALS, ['foo'], 'foo')).toBe(MR.MATCHED)
                }) 
            })
            describe('STARTS_WITH', function() {
                it('matches empty string', function() {
                    expect(matchString(MC.STARTS_WITH, [''], '')).toBe(MR.MATCHED)
                    expect(matchString(MC.STARTS_WITH, [''], 'foo')).toBe(MR.MATCHED)
                })
                it('matches non-empty string', function() {
                    expect(matchString(MC.STARTS_WITH, ['f'], '')).toBe(MR.UNMATCHED)
                    expect(matchString(MC.STARTS_WITH, ['f'], 'foo')).toBe(MR.MATCHED)
                })
            })
            describe('ENDS_WITH', function() {
                it('matches non-empty string', function() {
                    expect(matchString(MC.ENDS_WITH, ['f'], '')).toBe(MR.UNMATCHED)
                    expect(matchString(MC.ENDS_WITH, ['f'], 'oof')).toBe(MR.MATCHED)
                })
            })
            describe('CONTAINS', function() {
                it('matches empty string', function() {
                    expect(matchString(MC.CONTAINS, [''], 'foo')).toBe(MR.MATCHED)
                })
                it('matches non-empty string', function() {
                    expect(matchString(MC.CONTAINS, ['f'], '')).toBe(MR.UNMATCHED)
                    expect(matchString(MC.CONTAINS, ['f'], 'foo')).toBe(MR.MATCHED)
                })
            })
            describe('MATCHES_REGEX', function() {
                it('returns INVALID_REGEX for bad condition', function() {
                    expect(matchString(MC.MATCHES_REGEX, ['x[y'], '...')).toBe(MR.INVALID_REGEX)
                })
                it('returns UNMATCHED for input not matching expr', function() {
                    expect(matchString(MC.MATCHES_REGEX, ['/f.*/bar'], '/foobar')).toBe(MR.UNMATCHED)
                })
                it('returns MATCHED for input matching expr', function() {
                    expect(matchString(MC.MATCHES_REGEX, ['/f.*/bar'], '/foo/bar')).toBe(MR.MATCHED)
                })
            })
            describe('IS_IN_LIST', function() {
                it('returns EMPTY_CONDITION with no list', function() {
                    expect(matchString(MC.IS_IN_LIST, undefined, '')).toBe(MR.EMPTY_CONDITION)
                    expect(matchString(MC.IS_IN_LIST, [], '')).toBe(MR.EMPTY_CONDITION)
                })
                it('return UNMATCHED for input not in list', function() {
                    expect(matchString(MC.IS_IN_LIST, ['/foo', '/bar'], '/baz')).toBe(MR.UNMATCHED)
                })
                it('return MATCHED for input in list', function() {
                    expect(matchString(MC.IS_IN_LIST, ['/foo', '/bar'], '/foo')).toBe(MR.MATCHED)
                })
            })
            describe('IS_NOT_EMPTY', function() {
                it('rejects empty string', function() {
                    expect(matchString(MC.IS_NOT_EMPTY, undefined, '')).toBe(MR.EMPTY_CONDITION)
                    expect(matchString(MC.IS_NOT_EMPTY, [], '')).toBe(MR.EMPTY_CONDITION)
                    expect(matchString(MC.IS_NOT_EMPTY, [''], '')).toBe(MR.UNMATCHED)
                })
                it('matches non-empty string', function() {
                    expect(matchString(MC.IS_NOT_EMPTY, undefined, 'foo')).toBe(MR.EMPTY_CONDITION)
                    expect(matchString(MC.IS_NOT_EMPTY, [], 'foo')).toBe(MR.EMPTY_CONDITION)
                    expect(matchString(MC.IS_NOT_EMPTY, 'a', 'foo')).toBe(MR.MATCHED)
                })
            })
        })
    })

    describe('matchKeyValue()', function() {
        function matchKeyValue(type, keys, values, input) {
            var spec;

            spec = { type: type, key: { type: MC.EQUALS, matchStrings: Array.isArray(keys) ? keys : [ keys ] }};
            if(values) spec.value = { type: MC.EQUALS, matchStrings: Array.isArray(values) ? values : [ values ] };

            return Matcher.matchKeyValue(spec, input);
        }

        it('returns true if no key to match', function() {
            expect(matchKeyValue('EQUALS', [])).toBe(true);
        })
        it('returns false if passed multiple keys', function() {
            expect(matchKeyValue('EQUALS', ['a','b'])).toBe(false);
        })
        it('returns false if passed multiple values', function() {
            expect(matchKeyValue('EQUALS', 'a', ['a','b'])).toBe(false);
        })
        it('returns false if no key matches', function() {
            expect(matchKeyValue('EQUALS', 'a', null, { 'b': 'foo' })).toBe(false);
        })
        it('returns false if no value matches', function() {
            expect(matchKeyValue('EQUALS', 'a', 'b', { 'a': 'foo' })).toBe(false);
        })
        it('returns true if any existence check passes', function() {
            expect(matchKeyValue('CHECK_FOR_EXISTENCE', 'a', null, { a: 'foo' })).toBe(true);
        })
        it('returns true if any value check passes', function() {
            expect(matchKeyValue('EQUALS', 'a', 'foo', { a: 'foo' })).toBe(true);
        })
    })

    describe('matchRepeatedKeyValue()', function() {
        it('returns true if there are no rules to match', function() {
            expect(Matcher.matchRepeatedKeyValue(null)).toBe(true);
            expect(Matcher.matchRepeatedKeyValue([])).toBe(true);
        })
        it('returns true if there is a match', function() {
            expect(Matcher.matchRepeatedKeyValue(
                [{ type: 'CHECK_FOR_EXISTENCE', key: { type: 'EQUALS', matchStrings: ['a'] }}],
                { 'a': 'foo' }
            )).toBe(true);
        })
        it('returns false if there is no match', function() {
            expect(Matcher.matchRepeatedKeyValue(
                [{ type: 'CHECK_FOR_EXISTENCE', key: { type: 'EQUALS', matchStrings: ['b'] }}],
                { 'a': 'foo' }
            )).toBe(false);
        })
    })
})
