module.exports = require('./lib/core/agent');
